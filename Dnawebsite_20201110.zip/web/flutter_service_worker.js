'use strict';
const MANIFEST = 'flutter-app-manifest';
const TEMP = 'flutter-temp-cache';
const CACHE_NAME = 'flutter-app-cache';
const RESOURCES = {
  "assets/asset/Banner.png": "be52669beb27dc225ba75c6a4a7ec239",
"assets/asset/Engagement-v9.mp4": "b84b1ea38d5ce1321c22178399b92c9d",
"assets/asset/hsbc-logo.png": "0c2269ee33c78381430e7976cc98a43a",
"assets/asset/Image1.png": "0a396f4921c360130c540ce3c3d16c18",
"assets/asset/landing_ournews_section.PNG": "8bfa358d1406a8434797a5029dc1eae8",
"assets/asset/LowerBanner.png": "0cc34eb8919448b52e3f39d5b1f8279a",
"assets/asset/News1.png": "d6f3b579461e27ea04cc1ba88777d101",
"assets/asset/News2.png": "3c37064d9f3bf950ca6e65aa54640436",
"assets/asset/News3.png": "6035b9f416d7ee6115a5feade91b0924",
"assets/asset/noel_video.mp4": "91cbec9f59243ef895892d6333f01b94",
"assets/asset/our_news_1.png": "e8a116a216ab6ca262b790f9f9288535",
"assets/asset/our_news_2.png": "fdc3ee4c3a734c670a1b022aaa588e3b",
"assets/asset/our_news_3.png": "d81eb4d32532798421f5e5e7f9bc9570",
"assets/asset/our_news_4.png": "3068a2965e839e634319257a1aa43499",
"assets/asset/our_news_5.png": "9163b23de639cada906907746a08bb45",
"assets/asset/our_news_row1_bg.png": "17bbef4f568f0c3de017c2c0e2baf1f7",
"assets/asset/RanilPic.png": "9a632311ad74e8d845115a36aef51c04",
"assets/asset/row1_banner.png": "be52669beb27dc225ba75c6a4a7ec239",
"assets/asset/row1_bg.png": "839e572e7f68e110e3718a03924b294e",
"assets/asset/row3-fg.png": "0a396f4921c360130c540ce3c3d16c18",
"assets/asset/row3_01.png": "e0169ea473fee343493b76a455b13921",
"assets/asset/row3_02.png": "fc6a1ca2839069cebe0a1d8185e26554",
"assets/asset/row3_03.png": "b2218a0132de8c00904b9a1a712c6734",
"assets/asset/row3_04.png": "e7e29733a761bdfb781d27c870d75582",
"assets/asset/SearchIcon.png": "62279ba7013db9be701a382f15a972e7",
"assets/asset/team_all_in_one.png": "0c6e9c4c58ab0677afdb8ab248eaffec",
"assets/asset/TopBanner.png": "29742a2c8256ba86488fa2da1bf423f4",
"assets/asset/T_Banjamin.png": "c508a5d571a977d7f64724e82f4946e8",
"assets/asset/T_Charlotte.png": "92b55ba246deeea008fae9b5cf7af693",
"assets/asset/T_Chris.png": "578c7c58c77f49ef7f92944c3935fb25",
"assets/asset/T_Faiza.png": "8597803204a091ed42323044fbdd27ca",
"assets/asset/T_jeffery.png": "0f20c12286f723394dcf2ace753aadb3",
"assets/asset/T_Laura.png": "00f4b25aea6a13ccd77b72fc7deae17c",
"assets/asset/T_Michael_48.png": "5100a832488a8b2ed573229d7aab0efe",
"assets/asset/T_mitesh.png": "03aa6fa52711f7db66250c45bc2052a0",
"assets/asset/T_Navin.png": "48ed7dfbcb6618aa2587c8cbcf24ed84",
"assets/asset/T_Nicola.png": "6ee8ac1406b87ed1f465dfae198a7043",
"assets/asset/T_ranil.png": "de9975dd8a9bc727ca4ba184593931d8",
"assets/asset/T_richardD.png": "c217691f7f66139886e6fecd56337561",
"assets/asset/T_rob.png": "cd34a0e7e570d7a3e1e0036dbfc45009",
"assets/asset/T_Upendra.png": "c9c9ed0d1fd3f9fdd304eae41cfad7d6",
"assets/asset/T_Yusuf.png": "b2e4bb8ba337ef01f357ec69c2a8a4c1",
"assets/asset/T__RichardB.png": "90d1fc9cb803d4346a42520217735b6d",
"assets/asset/Untitled-1_03.png": "bd1347238a30ab145fc8555c89ae4339",
"assets/asset/Untitled-1_05.png": "5a77019333c2fe19e5b05a0c8d396f59",
"assets/asset/Untitled-1_07.png": "98ad7d3639803f2540b20ad17b064f16",
"assets/asset/Untitled-1_12.png": "0fd5b203bc0d457ff99bf858a151519e",
"assets/asset/Untitled-1_13.png": "c2b63dce6eaefe76d2890764884dda2e",
"assets/asset/Untitled-1_14.png": "1ff692aaaa3e75aea821046b927cb0be",
"assets/asset/Video.png": "f231bf50466adc5f06a7ebd7eda31f34",
"assets/asset/VideoThumnail.png": "684d46ccc4288e3f9ad14bc503aaa63e",
"assets/asset/Website-%252520StyleGuide.png": "c74f2903392752431bf5fc52be11aea9",
"assets/asset/Who%2520We%2520Are%2520-%2520Our%2520News.docx%2520-%2520Shortcut.lnk": "e04b7ec1b3741efa23615474d54e929f",
"assets/asset/who_we_are_lower_bg.png": "ecde1773e02de91cf27226141d13ba46",
"assets/asset/world_map.png": "e80a4d2357323120641188c0008463b2",
"assets/AssetManifest.json": "779b64c628e7fc358546f926a139335e",
"assets/FontManifest.json": "e2cf9d51b17de2a0b0693b315c647ec7",
"assets/fonts/MaterialIcons-Regular.otf": "1288c9e28052e028aba623321f7826ac",
"assets/fonts/Pacifico-Regular.ttf": "9b94499ccea3bd82b24cb210733c4b5e",
"assets/fonts/UniversNextforHSBC-Bold.otf": "52331d34fcd95d328de249fd2333577f",
"assets/fonts/UniversNextforHSBC-Regular.ttf": "b8129c471236f5b55f02feada1088f93",
"assets/fonts/UniversNextforHSBC-Thin.ttf": "0930d6b344c539d34d59c9c40ac9ece4",
"assets/NOTICES": "5dc6d0b07cb0d6c5591ab25e06caa0e4",
"assets/packages/cupertino_icons/assets/CupertinoIcons.ttf": "115e937bb829a890521f72d2e664b632",
"assets/packages/open_iconic_flutter/assets/open-iconic.woff": "3cf97837524dd7445e9d1462e3c4afe2",
"favicon.png": "5dcef449791fa27946b3d35ad8803796",
"icons/Icon-192.png": "ac9a721a12bbc803b44f645561ecb1e1",
"icons/Icon-512.png": "96e752610906ba2a93c65f8abe1645f1",
"index.html": "cd065d50302359e3f68caefa93454209",
"/": "cd065d50302359e3f68caefa93454209",
"main.dart.js": "3c4c7bab7a5a7732f3d04f90e6e74e27",
"manifest.json": "aef03bc5138a8e12a78ddd4b291c91d3",
"version.json": "6d85168016f4814f4228f583538a0b19"
};

// The application shell files that are downloaded before a service worker can
// start.
const CORE = [
  "/",
"main.dart.js",
"index.html",
"assets/NOTICES",
"assets/AssetManifest.json",
"assets/FontManifest.json"];
// During install, the TEMP cache is populated with the application shell files.
self.addEventListener("install", (event) => {
  self.skipWaiting();
  return event.waitUntil(
    caches.open(TEMP).then((cache) => {
      return cache.addAll(
        CORE.map((value) => new Request(value + '?revision=' + RESOURCES[value], {'cache': 'reload'})));
    })
  );
});

// During activate, the cache is populated with the temp files downloaded in
// install. If this service worker is upgrading from one with a saved
// MANIFEST, then use this to retain unchanged resource files.
self.addEventListener("activate", function(event) {
  return event.waitUntil(async function() {
    try {
      var contentCache = await caches.open(CACHE_NAME);
      var tempCache = await caches.open(TEMP);
      var manifestCache = await caches.open(MANIFEST);
      var manifest = await manifestCache.match('manifest');
      // When there is no prior manifest, clear the entire cache.
      if (!manifest) {
        await caches.delete(CACHE_NAME);
        contentCache = await caches.open(CACHE_NAME);
        for (var request of await tempCache.keys()) {
          var response = await tempCache.match(request);
          await contentCache.put(request, response);
        }
        await caches.delete(TEMP);
        // Save the manifest to make future upgrades efficient.
        await manifestCache.put('manifest', new Response(JSON.stringify(RESOURCES)));
        return;
      }
      var oldManifest = await manifest.json();
      var origin = self.location.origin;
      for (var request of await contentCache.keys()) {
        var key = request.url.substring(origin.length + 1);
        if (key == "") {
          key = "/";
        }
        // If a resource from the old manifest is not in the new cache, or if
        // the MD5 sum has changed, delete it. Otherwise the resource is left
        // in the cache and can be reused by the new service worker.
        if (!RESOURCES[key] || RESOURCES[key] != oldManifest[key]) {
          await contentCache.delete(request);
        }
      }
      // Populate the cache with the app shell TEMP files, potentially overwriting
      // cache files preserved above.
      for (var request of await tempCache.keys()) {
        var response = await tempCache.match(request);
        await contentCache.put(request, response);
      }
      await caches.delete(TEMP);
      // Save the manifest to make future upgrades efficient.
      await manifestCache.put('manifest', new Response(JSON.stringify(RESOURCES)));
      return;
    } catch (err) {
      // On an unhandled exception the state of the cache cannot be guaranteed.
      console.error('Failed to upgrade service worker: ' + err);
      await caches.delete(CACHE_NAME);
      await caches.delete(TEMP);
      await caches.delete(MANIFEST);
    }
  }());
});

// The fetch handler redirects requests for RESOURCE files to the service
// worker cache.
self.addEventListener("fetch", (event) => {
  if (event.request.method !== 'GET') {
    return;
  }
  var origin = self.location.origin;
  var key = event.request.url.substring(origin.length + 1);
  // Redirect URLs to the index.html
  if (key.indexOf('?v=') != -1) {
    key = key.split('?v=')[0];
  }
  if (event.request.url == origin || event.request.url.startsWith(origin + '/#') || key == '') {
    key = '/';
  }
  // If the URL is not the RESOURCE list then return to signal that the
  // browser should take over.
  if (!RESOURCES[key]) {
    return;
  }
  // If the URL is the index.html, perform an online-first request.
  if (key == '/') {
    return onlineFirst(event);
  }
  event.respondWith(caches.open(CACHE_NAME)
    .then((cache) =>  {
      return cache.match(event.request).then((response) => {
        // Either respond with the cached resource, or perform a fetch and
        // lazily populate the cache.
        return response || fetch(event.request).then((response) => {
          cache.put(event.request, response.clone());
          return response;
        });
      })
    })
  );
});

self.addEventListener('message', (event) => {
  // SkipWaiting can be used to immediately activate a waiting service worker.
  // This will also require a page refresh triggered by the main worker.
  if (event.data === 'skipWaiting') {
    self.skipWaiting();
    return;
  }
  if (event.data === 'downloadOffline') {
    downloadOffline();
    return;
  }
});

// Download offline will check the RESOURCES for all files not in the cache
// and populate them.
async function downloadOffline() {
  var resources = [];
  var contentCache = await caches.open(CACHE_NAME);
  var currentContent = {};
  for (var request of await contentCache.keys()) {
    var key = request.url.substring(origin.length + 1);
    if (key == "") {
      key = "/";
    }
    currentContent[key] = true;
  }
  for (var resourceKey in Object.keys(RESOURCES)) {
    if (!currentContent[resourceKey]) {
      resources.push(resourceKey);
    }
  }
  return contentCache.addAll(resources);
}

// Attempt to download the resource online before falling back to
// the offline cache.
function onlineFirst(event) {
  return event.respondWith(
    fetch(event.request).then((response) => {
      return caches.open(CACHE_NAME).then((cache) => {
        cache.put(event.request, response.clone());
        return response;
      });
    }).catch((error) => {
      return caches.open(CACHE_NAME).then((cache) => {
        return cache.match(event.request).then((response) => {
          if (response != null) {
            return response;
          }
          throw error;
        });
      });
    })
  );
}
